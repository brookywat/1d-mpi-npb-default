

#include "mpi.h"
#include "type.h"

int  node, no_nodes, total_nodes, root, comm_setup, comm_solve, comm_rhs, dp_type;

logical active;
//_common_mpi_stuff_node, no_nodes, total_nodes, root, comm_setup, comm_solve, comm_rhs, dp_type, active;

//int DEFAULT_TAG= 0;
