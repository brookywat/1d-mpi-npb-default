

#include "mpi.h"
#include "type.h"
#include "header.h"

int  node, no_nodes, total_nodes, root, comm_setup, comm_solve, comm_rhs, dp_type, x;
double time_xsolve, time_ysolve, time_zsolve,  time_rhs;
int rloop1, rloop2, rloop3;

logical active;
//_common_mpi_stuff_node, no_nodes, total_nodes, root, comm_setup, comm_solve, comm_rhs, dp_type, active;

//int DEFAULT_TAG= 0;
