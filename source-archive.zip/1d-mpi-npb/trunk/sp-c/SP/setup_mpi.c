

      //subroutine setup_mpi


      
#include "mpinpb.h"
#include "npbparams.h"


void setup_mpi()
{
	int error, nc, color;
        //MPI_Init(&arg, &argv1);
	MPI_Comm_size(MPI_COMM_WORLD, &total_nodes);
	MPI_Comm_rank(MPI_COMM_WORLD, &node);
         
	if (!CONVERTDOUBLE) 
		dp_type = MPI_DOUBLE_PRECISION;
	else
		 dp_type = MPI_REAL;
	   

//     compute square root; add small number to allow for roundoff

     // nc = (int) sqrt((double)(total_nodes) + 0.00001);

/*---------------------------------------------------------------------
c We handle a non-square number of nodes by making the excess nodes
c inactive. However, we can never handle more cells than were compiled
c in. 
c---------------------------------------------------------------------*/

     // if (nc > maxcells) nc = maxcells;

      /*if (node >= nc*nc)
      { 
         active = false;
         color = 1;
      }  	
      else
      {
         active = true;
         color = 0;
      }
      
      
      mpi_comm_split(MPI_COMM_WORLD,color,node,comm_setup,error);
      if (! active) return;

      mpi_comm_size(comm_setup, no_nodes, error);
      mpi_comm_dup(comm_setup, comm_solve, error);
      mpi_comm_dup(comm_setup, comm_rhs, error);*/
      
/*c---------------------------------------------------------------------
c     let node 0 be the root for the group (there is only one)
c---------------------------------------------------------------------*/
      root = 0;

      

}
