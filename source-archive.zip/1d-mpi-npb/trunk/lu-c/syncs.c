//-------------------------------------------------------------------------//
//                                                                         //
//  This benchmark is an OpenMP C version of the NPB LU code. This OpenMP  //
//  C version is developed by the Center for Manycore Programming at Seoul //
//  National University and derived from the OpenMP Fortran versions in    //
//  "NPB3.3-OMP" developed by NAS.                                         //
//                                                                         //
//  Permission to use, copy, distribute and modify this software for any   //
//  purpose with or without fee is hereby granted. This software is        //
//  provided "as is" without express or implied warranty.                  //
//                                                                         //
//  Information on NPB 3.3, including the technical report, the original   //
//  specifications, source code, results and information on how to submit  //
//  new results, is available at:                                          //
//                                                                         //
//           http://www.nas.nasa.gov/Software/NPB/                         //
//                                                                         //
//  Send comments or suggestions for this OpenMP C version to              //
//  cmp@aces.snu.ac.kr                                                     //
//                                                                         //
//          Center for Manycore Programming                                //
//          School of Computer Science and Engineering                     //
//          Seoul National University                                      //
//          Seoul 151-744, Korea                                           //
//                                                                         //
//          E-mail:  cmp@aces.snu.ac.kr                                    //
//                                                                         //
//-------------------------------------------------------------------------//

//-------------------------------------------------------------------------//
// Authors: Sangmin Seo, Jungwon Kim, Jun Lee, Jeongho Nah, Gangwon Jo,    //
//          and Jaejin Lee                                                 //
//-------------------------------------------------------------------------//

#include "applu.incl"


#include <mpi.h>

//---------------------------------------------------------------------
// Thread synchronization for pipeline operation
//---------------------------------------------------------------------

void sync_left(int ldmx, int ldmy, int ldmz,
               double v[ldmz][ldmy/2*2+1][ldmx/2*2+1][5])
{


   MPI_Status status;
   int my_id_syn = 0, id_num_syn = 0,pros_num_syn = 0, root_process_syn;
   int ierr_syn;

   MPI_Comm comm;

   root_process_syn = 0;

   ierr_syn = MPI_Comm_rank(MPI_COMM_WORLD, &my_id_syn);
   ierr_syn = MPI_Comm_size(MPI_COMM_WORLD, &pros_num_syn);


  int neigh;

  if (iam > 0 && iam <= mthreadnum) {
    neigh = iam - 1;
    while (isync[neigh] == 0) {
//      #pragma omp flush(isync)
          if (my_id_syn == root_process_syn){
           int size = (ISIZ2+1);
          MPI_Bcast( isync, size, MPI_DOUBLE, root_process_syn, MPI_COMM_WORLD);
          }
    }
    int MPI_Barrier( MPI_Comm comm );
    isync[neigh] = 0;
//    #pragma omp flush(isync,v)
          if (my_id_syn == root_process_syn){
           int size = (ISIZ2+1);
           int vsize = ldmz*(ldmy/2*2+1)*(ldmx/2*2+1)*5;
          MPI_Bcast( isync, size, MPI_DOUBLE, root_process_syn, MPI_COMM_WORLD);
          MPI_Bcast( v, vsize, MPI_DOUBLE, root_process_syn, MPI_COMM_WORLD);
          }
   int MPI_Barrier( MPI_Comm comm );
  }
}


//---------------------------------------------------------------------
// Thread synchronization for pipeline operation
//---------------------------------------------------------------------
void sync_right(int ldmx, int ldmy, int ldmz,
                double v[ldmz][ldmy/2*2+1][ldmx/2*2+1][5])
{

   MPI_Status status;
   int my_id_syn = 0, id_num_syn = 0, pros_num_syn = 0, root_process_syn;
   int ierr_syn;

   MPI_Comm comm;

   root_process_syn = 0;

   ierr_syn = MPI_Comm_rank(MPI_COMM_WORLD, &my_id_syn);
   ierr_syn = MPI_Comm_size(MPI_COMM_WORLD, &pros_num_syn);

  if (iam < mthreadnum) {
//    #pragma omp flush(isync,v)
       if (my_id_syn == root_process_syn){
           int size = (ISIZ2+1);
           int vsize = ldmz*(ldmy/2*2+1)*(ldmx/2*2+1)*5;
          MPI_Bcast( isync, size, MPI_DOUBLE, root_process_syn, MPI_COMM_WORLD);
          MPI_Bcast( v, vsize, MPI_DOUBLE, root_process_syn, MPI_COMM_WORLD);
          }
//       int MPI_Barrier( MPI_Comm comm );

    while (isync[iam] == 1) {
//      #pragma omp flush(isync)

          if (my_id_syn == root_process_syn){
           int size = (ISIZ2+1);
          MPI_Bcast( isync, size, MPI_DOUBLE, root_process_syn, MPI_COMM_WORLD);
          }
    }

//    int MPI_Barrier( MPI_Comm comm );
    isync[iam] = 1;
//    #pragma omp flush(isync)

          if (my_id_syn == root_process_syn){
           int size = (ISIZ2+1);
          MPI_Bcast( isync, size, MPI_DOUBLE, root_process_syn, MPI_COMM_WORLD);
          }

//    int MPI_Barrier( MPI_Comm comm );
  }
}



