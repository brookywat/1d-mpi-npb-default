//-------------------------------------------------------------------------//
//                                                                         //
//  This benchmark is an OpenMP C version of the NPB LU code. This OpenMP  //
//  C version is developed by the Center for Manycore Programming at Seoul //
//  National University and derived from the OpenMP Fortran versions in    //
//  "NPB3.3-OMP" developed by NAS.                                         //
//                                                                         //
//  Permission to use, copy, distribute and modify this software for any   //
//  purpose with or without fee is hereby granted. This software is        //
//  provided "as is" without express or implied warranty.                  //
//                                                                         //
//  Information on NPB 3.3, including the technical report, the original   //
//  specifications, source code, results and information on how to submit  //
//  new results, is available at:                                          //
//                                                                         //
//           http://www.nas.nasa.gov/Software/NPB/                         //
//                                                                         //
//  Send comments or suggestions for this OpenMP C version to              //
//  cmp@aces.snu.ac.kr                                                     //
//                                                                         //
//          Center for Manycore Programming                                //
//          School of Computer Science and Engineering                     //
//          Seoul National University                                      //
//          Seoul 151-744, Korea                                           //
//                                                                         //
//          E-mail:  cmp@aces.snu.ac.kr                                    //
//                                                                         //
//-------------------------------------------------------------------------//

//-------------------------------------------------------------------------//
// Authors: Sangmin Seo, Jungwon Kim, Jun Lee, Jeongho Nah, Gangwon Jo,    //
//          and Jaejin Lee                                                 //
//-------------------------------------------------------------------------//

#include "applu.incl"

#include <mpi.h>

//---------------------------------------------------------------------
// set the boundary values of dependent variables
//---------------------------------------------------------------------
void setbv()
{
  //---------------------------------------------------------------------
  // local variables
  //---------------------------------------------------------------------
  int i, j, k, m;
  double temp1[5], temp2[5];


   MPI_Status status;
   int my_id = 0, id_num = 0,upper_bound = 0, lower_bound = 0, pros_num = 0, average_span = 0, root_process=0;
   int ierr,upper_bound_two = 0, lower_bound_two = 0, average_span_two = 0;

   MPI_Comm comm;

   root_process = 0;

   ierr = MPI_Comm_rank(MPI_COMM_WORLD, &my_id);
   ierr = MPI_Comm_size(MPI_COMM_WORLD, &pros_num);
   average_span = (nx)/pros_num;
   average_span_two = (nz)/pros_num;

        if (my_id == root_process){

        lower_bound = 0;
        upper_bound = average_span;

        lower_bound_two = 0;
        upper_bound_two = average_span_two;

           if ((my_id+1)  == pros_num){
                if(upper_bound < nx ){
                        upper_bound = nx;
                   }
                if(upper_bound_two < nz ){
                        upper_bound_two = nz;
                   }
                }

         }
        else{

        lower_bound = (average_span *  my_id) ;
        upper_bound = average_span * (my_id+1);

        lower_bound_two = (average_span_two *  my_id) ;
        upper_bound_two = average_span_two * (my_id+1);


          if ((my_id+1) == pros_num){
                if(upper_bound < nx ){
                        upper_bound = nx;
                   }
                if(upper_bound_two < nz ){
                        upper_bound_two = nz;
                   }

                 }
             }




  //---------------------------------------------------------------------
  // set the dependent variable values along the top and bottom faces
  //---------------------------------------------------------------------
//  #pragma omp parallel default(shared) private(i,j,k,m,temp1,temp2) \
                                       shared(nx,ny,nz)
  {

  for (j = 0; j < ny; j++) {
    for (i = 0; i < nx; i++) {
      exact( i, j, 0, temp1 );
      exact( i, j, nz-1, temp2 );
      for (m = 0; m < 5; m++) {
        u[0][j][i][m] = temp1[m];
        u[nz-1][j][i][m] = temp2[m];
      }
    }
  }


int scount_three = (ISIZ3)*average_span*(ISIZ1/2*2+1)*(5);
int rcount_three = scount_three;
//ierr=MPI_Allgather( &u[0][lower_bound][0][0], scount_three, MPI_DOUBLE, &u[0][0][0][0], rcount_three, MPI_DOUBLE, MPI_COMM_WORLD);

//ierr=MPI_Allgather( &u[11][lower_bound][0][0], scount_three, MPI_DOUBLE, &u[11][0][0][0], rcount_three, MPI_DOUBLE, MPI_COMM_WORLD);
/**/
  //---------------------------------------------------------------------
  // set the dependent variable values along north and south faces
  //---------------------------------------------------------------------
//  #pragma omp for schedule(static) nowait
//  for (k = 0; k < nz; k++) {
for (k = lower_bound_two; k < upper_bound_two; k++) {
    for (i = 0; i < nx; i++) {
      exact( i, 0, k, temp1 );
      exact( i, ny-1, k, temp2 );
      for (m = 0; m < 5; m++) {
        u[k][0][i][m] = temp1[m];
        u[k][ny-1][i][m] = temp2[m];
      }
    }
  }

int scount = average_span_two*(ISIZ2/2*2+1)*(ISIZ1/2*2+1)*(5);
int rcount = scount;
//ierr=MPI_Allgather( &u[lower_bound_two][0][0][0], scount, MPI_DOUBLE, &u[0][0][0][0], rcount, MPI_DOUBLE, MPI_COMM_WORLD);

  //---------------------------------------------------------------------
  // set the dependent variable values along east and west faces
  //---------------------------------------------------------------------
//  #pragma omp for schedule(static) nowait
//  for (k = 0; k < nz; k++) {
for (k = lower_bound_two; k < upper_bound_two; k++) {
    for (j = 0; j < ny; j++) {
      exact( 0, j, k, temp1 );
      exact( nx-1, j, k, temp2 );
      for (m = 0; m < 5; m++) {
        u[k][j][0][m] = temp1[m];
        u[k][j][nx-1][m] = temp2[m];
      }
    }
  }


int scount_two = average_span_two*(ISIZ2/2*2+1)*(ISIZ1/2*2+1)*(5);
int rcount_two = scount_two;
//ierr=MPI_Allgather( &u[lower_bound_two][0][0][0], scount_two, MPI_DOUBLE, &u[0][0][0][0], rcount_two, MPI_DOUBLE, MPI_COMM_WORLD);

  } //end parallel
}

