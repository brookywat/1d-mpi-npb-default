//-------------------------------------------------------------------------//
//                                                                         //
//  This benchmark is an OpenMP C version of the NPB LU code. This OpenMP  //
//  C version is developed by the Center for Manycore Programming at Seoul //
//  National University and derived from the OpenMP Fortran versions in    //
//  "NPB3.3-OMP" developed by NAS.                                         //
//                                                                         //
//  Permission to use, copy, distribute and modify this software for any   //
//  purpose with or without fee is hereby granted. This software is        //
//  provided "as is" without express or implied warranty.                  //
//                                                                         //
//  Information on NPB 3.3, including the technical report, the original   //
//  specifications, source code, results and information on how to submit  //
//  new results, is available at:                                          //
//                                                                         //
//           http://www.nas.nasa.gov/Software/NPB/                         //
//                                                                         //
//  Send comments or suggestions for this OpenMP C version to              //
//  cmp@aces.snu.ac.kr                                                     //
//                                                                         //
//          Center for Manycore Programming                                //
//          School of Computer Science and Engineering                     //
//          Seoul National University                                      //
//          Seoul 151-744, Korea                                           //
//                                                                         //
//          E-mail:  cmp@aces.snu.ac.kr                                    //
//                                                                         //
//-------------------------------------------------------------------------//

//-------------------------------------------------------------------------//
// Authors: Sangmin Seo, Jungwon Kim, Jun Lee, Jeongho Nah, Gangwon Jo,    //
//          and Jaejin Lee                                                 //
//-------------------------------------------------------------------------//

#include "applu.incl"

#include <mpi.h>

//---------------------------------------------------------------------
//
// set the initial values of independent variables based on tri-linear
// interpolation of boundary values in the computational space.
//
//---------------------------------------------------------------------
void setiv()
{
  //---------------------------------------------------------------------
  // local variables
  //---------------------------------------------------------------------
  int i, j, k, m;
  double xi, eta, zeta;
  double pxi, peta, pzeta;
  double ue_1jk[5], ue_nx0jk[5], ue_i1k[5];
  double ue_iny0k[5], ue_ij1[5], ue_ijnz[5];



   MPI_Status status;
   int my_id = 0, id_num = 0,upper_bound = 0, lower_bound = 0, pros_num = 0, average_span = 0, root_process=0;
   int ierr,upper_bound_two = 0, lower_bound_two = 0, average_span_two = 0, last_pros_bound =0;

//int disps[pros_num];
int *disps;
int rcounts[pros_num];
int *kdeltas;
 int p;


   MPI_Comm comm;

   root_process = 0;

   ierr = MPI_Comm_rank(MPI_COMM_WORLD, &my_id);
   ierr = MPI_Comm_size(MPI_COMM_WORLD, &pros_num);


   average_span = (nz-2)/pros_num;

        if (my_id == root_process){

        lower_bound = 1;
        upper_bound = average_span;


           if ((my_id+1)  == pros_num){
                if(upper_bound < (nz-2) ){
                        upper_bound = (nz-2);
                   }
                }
         }
        else{

        lower_bound = (average_span *  my_id)+1;
        upper_bound = average_span * (my_id+1);

          if ((my_id+1) == pros_num){
                if(upper_bound < (nz-2) ){
                        last_pros_bound = ((nz-2)-lower_bound)+1;
                        upper_bound = (nz-2);
                   }
                 }
             }




//  #pragma omp parallel for default(shared) private(i,j,k,m,pxi,peta,pzeta, \
              xi,eta,zeta,ue_ijnz,ue_ij1,ue_iny0k,ue_i1k,ue_nx0jk,ue_1jk)  \
              shared(nx0,ny0,nz)
//  for (k = 1; k <= nz - 2; k++) {

for (k = lower_bound; k <= upper_bound; k++) {
    zeta = ( (double)k ) / (nz-1);
    for (j = 1; j < ny - 1; j++) {
      eta = ( (double)j ) / (ny0-1);
      for (i = 1; i < nx - 1; i++) {
        xi = ( (double)i ) / (nx0-1);
        exact(0, j, k, ue_1jk);
        exact(nx0-1, j, k, ue_nx0jk);
        exact(i, 0, k, ue_i1k);
        exact(i, ny0-1, k, ue_iny0k);
        exact(i, j, 0, ue_ij1);
        exact(i, j, nz-1, ue_ijnz);

        for (m = 0; m < 5; m++) {
          pxi =   ( 1.0 - xi ) * ue_1jk[m]
                        + xi   * ue_nx0jk[m];
          peta =  ( 1.0 - eta ) * ue_i1k[m]
                        + eta   * ue_iny0k[m];
          pzeta = ( 1.0 - zeta ) * ue_ij1[m]
                        + zeta   * ue_ijnz[m];

          u[k][j][i][m] = pxi + peta + pzeta
            - pxi * peta - peta * pzeta - pzeta * pxi
            + pxi * peta * pzeta;
        }
      }
    }
  }



//ierr = MPI_Alltoallv(u[my_id],sendcounts,sdispls,MPI_DOUBLE,u[my_id],recvcounts,rdispls,MPI_DOUBLE,MPI_COMM_WORLD);            
//double scount = (11.084023611111)*(ISIZ2/2*2+1)*(ISIZ1/2*2+1)*(5);

//..double scount = (average_span)*(ISIZ2/2*2+1)*(ISIZ1/2*2+1)*(5);
//..double rcount = scount;

//ierr=MPI_Allgather( &u[lower_bound][0][0][0], scount, MPI_DOUBLE, &u[1][0][0][0], rcount, MPI_DOUBLE, MPI_COMM_WORLD);
//..ierr=MPI_Allgather( MPI_IN_PLACE, scount, MPI_DOUBLE, &u[1][0][0][0], rcount, MPI_DOUBLE, MPI_COMM_WORLD);
//int MPI_Barrier( MPI_Comm comm );



kdeltas = (int *) malloc(pros_num*sizeof(int));
disps = (int *) malloc(pros_num*sizeof(int));
disps[0] = 0;
rcounts[0] = kdeltas[0]*(ISIZ2/2*2+1)*(ISIZ1/2*2+1)*(5);
//double scount = (average_span)*(ISIZ2/2*2+1)*(ISIZ1/2*2+1)*(5);

for(p=0; p<pros_num; p++) {
       
        rcounts[p] = average_span*(ISIZ2/2*2+1)*(ISIZ1/2*2+1)*(5);
//          if ((pros_num >=4)&& ((my_id+1)== pros_num)){
//          rcounts[p] =  (last_pros_bound)*(ISIZ2/2*2+1)*(ISIZ1/2*2+1)*(5);
//                }
        disps[p] = disps[p-1] + rcounts[p-1];
    }


 ierr = MPI_Allgatherv(MPI_IN_PLACE,0,MPI_DATATYPE_NULL,&u[1][0][0][0],rcounts,disps,MPI_DOUBLE,MPI_COMM_WORLD);



}

