//-------------------------------------------------------------------------//
//                                                                         //
//  This benchmark is an OpenMP C version of the NPB LU code. This OpenMP  //
//  C version is developed by the Center for Manycore Programming at Seoul //
//  National University and derived from the OpenMP Fortran versions in    //
//  "NPB3.3-OMP" developed by NAS.                                         //
//                                                                         //
//  Permission to use, copy, distribute and modify this software for any   //
//  purpose with or without fee is hereby granted. This software is        //
//  provided "as is" without express or implied warranty.                  //
//                                                                         //
//  Information on NPB 3.3, including the technical report, the original   //
//  specifications, source code, results and information on how to submit  //
//  new results, is available at:                                          //
//                                                                         //
//           http://www.nas.nasa.gov/Software/NPB/                         //
//                                                                         //
//  Send comments or suggestions for this OpenMP C version to              //
//  cmp@aces.snu.ac.kr                                                     //
//                                                                         //
//          Center for Manycore Programming                                //
//          School of Computer Science and Engineering                     //
//          Seoul National University                                      //
//          Seoul 151-744, Korea                                           //
//                                                                         //
//          E-mail:  cmp@aces.snu.ac.kr                                    //
//                                                                         //
//-------------------------------------------------------------------------//

//-------------------------------------------------------------------------//
// Authors: Sangmin Seo, Jungwon Kim, Jun Lee, Jeongho Nah, Gangwon Jo,    //
//          and Jaejin Lee                                                 //
//-------------------------------------------------------------------------//

#include "applu.incl"

#include <mpi.h>

//---------------------------------------------------------------------
// compute the upper triangular part of the jacobian matrix
//---------------------------------------------------------------------
void jacu(int k)
{


MPI_Status status;
   int my_id = 0, id_num = 0,upper_bound = 0, lower_bound = 0, pros_num = 0, average_span = 0, root_process=0;
   int ierr, last_pros_bound =0;

/*
int *disps5;
int rcounts5[pros_num];
int *kdeltas5;
 int p5;
*/
 

   MPI_Comm comm;

   root_process = 0;

   ierr = MPI_Comm_rank(MPI_COMM_WORLD, &my_id);
   ierr = MPI_Comm_size(MPI_COMM_WORLD, &pros_num);
int *disps5;
int rcounts5[pros_num];
int *kdeltas5;
 int p5;


   average_span = (jend-jst)/pros_num;

        if (my_id == root_process){

        lower_bound = jst;
        upper_bound = average_span;

           if ((my_id+1)  == pros_num){
                if(upper_bound < jend-1 ){
                        upper_bound = jend-1;
                   }
                }

         }
        else{

        lower_bound = (average_span *  my_id) + 1;
        upper_bound = average_span * (my_id+1);

          if ((my_id+1) == pros_num){
                if(upper_bound < jend-1 ){
                        last_pros_bound = ((jend-1)-lower_bound)+1;
                        upper_bound = jend-1;
                   }
                 }
             }


  //---------------------------------------------------------------------
  // local variables
  //---------------------------------------------------------------------
  int i, j;
  double r43;
  double c1345;
  double c34;
  double tmp1, tmp2, tmp3;

  r43 = ( 4.0 / 3.0 );
  c1345 = C1 * C3 * C4 * C5;
  c34 = C3 * C4;

//  #pragma omp for schedule(static) nowait
//  for (j = jend - 1; j >= jst; j--) {

   for (j = upper_bound; j >= lower_bound; j--) {
    for (i = iend - 1; i >= ist; i--) {
      //---------------------------------------------------------------------
      // form the block daigonal
      //---------------------------------------------------------------------
      tmp1 = rho_i[k][j][i];
      tmp2 = tmp1 * tmp1;
      tmp3 = tmp1 * tmp2;

      du[j][i][0][0] = 1.0 + dt * 2.0 * ( tx1 * dx1 + ty1 * dy1 + tz1 * dz1 );
      du[j][i][1][0] = 0.0;
      du[j][i][2][0] = 0.0;
      du[j][i][3][0] = 0.0;
      du[j][i][4][0] = 0.0;

      du[j][i][0][1] =  dt * 2.0
        * ( - tx1 * r43 - ty1 - tz1 )
        * ( c34 * tmp2 * u[k][j][i][1] );
      du[j][i][1][1] =  1.0
        + dt * 2.0 * c34 * tmp1 
        * (  tx1 * r43 + ty1 + tz1 )
        + dt * 2.0 * ( tx1 * dx2 + ty1 * dy2 + tz1 * dz2 );
      du[j][i][2][1] = 0.0;
      du[j][i][3][1] = 0.0;
      du[j][i][4][1] = 0.0;

      du[j][i][0][2] = dt * 2.0
        * ( - tx1 - ty1 * r43 - tz1 )
        * ( c34 * tmp2 * u[k][j][i][2] );
      du[j][i][1][2] = 0.0;
      du[j][i][2][2] = 1.0
        + dt * 2.0 * c34 * tmp1
        * (  tx1 + ty1 * r43 + tz1 )
        + dt * 2.0 * ( tx1 * dx3 + ty1 * dy3 + tz1 * dz3 );
      du[j][i][3][2] = 0.0;
      du[j][i][4][2] = 0.0;

      du[j][i][0][3] = dt * 2.0
        * ( - tx1 - ty1 - tz1 * r43 )
        * ( c34 * tmp2 * u[k][j][i][3] );
      du[j][i][1][3] = 0.0;
      du[j][i][2][3] = 0.0;
      du[j][i][3][3] = 1.0
        + dt * 2.0 * c34 * tmp1
        * (  tx1 + ty1 + tz1 * r43 )
        + dt * 2.0 * ( tx1 * dx4 + ty1 * dy4 + tz1 * dz4 );
      du[j][i][4][3] = 0.0;

      du[j][i][0][4] = -dt * 2.0
        * ( ( ( tx1 * ( r43*c34 - c1345 )
                + ty1 * ( c34 - c1345 )
                + tz1 * ( c34 - c1345 ) ) * ( u[k][j][i][1]*u[k][j][i][1] )
              + ( tx1 * ( c34 - c1345 )
                + ty1 * ( r43*c34 - c1345 )
                + tz1 * ( c34 - c1345 ) ) * ( u[k][j][i][2]*u[k][j][i][2] )
              + ( tx1 * ( c34 - c1345 )
                + ty1 * ( c34 - c1345 )
                + tz1 * ( r43*c34 - c1345 ) ) * (u[k][j][i][3]*u[k][j][i][3])
            ) * tmp3
            + ( tx1 + ty1 + tz1 ) * c1345 * tmp2 * u[k][j][i][4] );

      du[j][i][1][4] = dt * 2.0
        * ( tx1 * ( r43*c34 - c1345 )
          + ty1 * (     c34 - c1345 )
          + tz1 * (     c34 - c1345 ) ) * tmp2 * u[k][j][i][1];
      du[j][i][2][4] = dt * 2.0
        * ( tx1 * ( c34 - c1345 )
          + ty1 * ( r43*c34 -c1345 )
          + tz1 * ( c34 - c1345 ) ) * tmp2 * u[k][j][i][2];
      du[j][i][3][4] = dt * 2.0
        * ( tx1 * ( c34 - c1345 )
          + ty1 * ( c34 - c1345 )
          + tz1 * ( r43*c34 - c1345 ) ) * tmp2 * u[k][j][i][3];
      du[j][i][4][4] = 1.0
        + dt * 2.0 * ( tx1 + ty1 + tz1 ) * c1345 * tmp1
        + dt * 2.0 * ( tx1 * dx5 + ty1 * dy5 + tz1 * dz5 );

      //---------------------------------------------------------------------
      // form the first block sub-diagonal
      //---------------------------------------------------------------------
      tmp1 = rho_i[k][j][i+1];
      tmp2 = tmp1 * tmp1;
      tmp3 = tmp1 * tmp2;

      au[j][i][0][0] = - dt * tx1 * dx1;
      au[j][i][1][0] =   dt * tx2;
      au[j][i][2][0] =   0.0;
      au[j][i][3][0] =   0.0;
      au[j][i][4][0] =   0.0;

      au[j][i][0][1] =  dt * tx2
        * ( - ( u[k][j][i+1][1] * tmp1 ) * ( u[k][j][i+1][1] * tmp1 )
            + C2 * qs[k][j][i+1] * tmp1 )
        - dt * tx1 * ( - r43 * c34 * tmp2 * u[k][j][i+1][1] );
      au[j][i][1][1] =  dt * tx2
        * ( ( 2.0 - C2 ) * ( u[k][j][i+1][1] * tmp1 ) )
        - dt * tx1 * ( r43 * c34 * tmp1 )
        - dt * tx1 * dx2;
      au[j][i][2][1] =  dt * tx2
        * ( - C2 * ( u[k][j][i+1][2] * tmp1 ) );
      au[j][i][3][1] =  dt * tx2
        * ( - C2 * ( u[k][j][i+1][3] * tmp1 ) );
      au[j][i][4][1] =  dt * tx2 * C2 ;

      au[j][i][0][2] =  dt * tx2
        * ( - ( u[k][j][i+1][1] * u[k][j][i+1][2] ) * tmp2 )
        - dt * tx1 * ( - c34 * tmp2 * u[k][j][i+1][2] );
      au[j][i][1][2] =  dt * tx2 * ( u[k][j][i+1][2] * tmp1 );
      au[j][i][2][2] =  dt * tx2 * ( u[k][j][i+1][1] * tmp1 )
        - dt * tx1 * ( c34 * tmp1 )
        - dt * tx1 * dx3;
      au[j][i][3][2] = 0.0;
      au[j][i][4][2] = 0.0;

      au[j][i][0][3] = dt * tx2
        * ( - ( u[k][j][i+1][1]*u[k][j][i+1][3] ) * tmp2 )
        - dt * tx1 * ( - c34 * tmp2 * u[k][j][i+1][3] );
      au[j][i][1][3] = dt * tx2 * ( u[k][j][i+1][3] * tmp1 );
      au[j][i][2][3] = 0.0;
      au[j][i][3][3] = dt * tx2 * ( u[k][j][i+1][1] * tmp1 )
        - dt * tx1 * ( c34 * tmp1 )
        - dt * tx1 * dx4;
      au[j][i][4][3] = 0.0;

      au[j][i][0][4] = dt * tx2
        * ( ( C2 * 2.0 * qs[k][j][i+1]
            - C1 * u[k][j][i+1][4] )
        * ( u[k][j][i+1][1] * tmp2 ) )
        - dt * tx1
        * ( - ( r43*c34 - c1345 ) * tmp3 * ( u[k][j][i+1][1]*u[k][j][i+1][1] )
            - (     c34 - c1345 ) * tmp3 * ( u[k][j][i+1][2]*u[k][j][i+1][2] )
            - (     c34 - c1345 ) * tmp3 * ( u[k][j][i+1][3]*u[k][j][i+1][3] )
            - c1345 * tmp2 * u[k][j][i+1][4] );
      au[j][i][1][4] = dt * tx2
        * ( C1 * ( u[k][j][i+1][4] * tmp1 )
            - C2
            * ( u[k][j][i+1][1]*u[k][j][i+1][1] * tmp2
              + qs[k][j][i+1] * tmp1 ) )
        - dt * tx1
        * ( r43*c34 - c1345 ) * tmp2 * u[k][j][i+1][1];
      au[j][i][2][4] = dt * tx2
        * ( - C2 * ( u[k][j][i+1][2]*u[k][j][i+1][1] ) * tmp2 )
        - dt * tx1
        * (  c34 - c1345 ) * tmp2 * u[k][j][i+1][2];
      au[j][i][3][4] = dt * tx2
        * ( - C2 * ( u[k][j][i+1][3]*u[k][j][i+1][1] ) * tmp2 )
        - dt * tx1
        * (  c34 - c1345 ) * tmp2 * u[k][j][i+1][3];
      au[j][i][4][4] = dt * tx2
        * ( C1 * ( u[k][j][i+1][1] * tmp1 ) )
        - dt * tx1 * c1345 * tmp1
        - dt * tx1 * dx5;

      //---------------------------------------------------------------------
      // form the second block sub-diagonal
      //---------------------------------------------------------------------
      tmp1 = rho_i[k][j+1][i];
      tmp2 = tmp1 * tmp1;
      tmp3 = tmp1 * tmp2;

      bu[j][i][0][0] = - dt * ty1 * dy1;
      bu[j][i][1][0] =   0.0;
      bu[j][i][2][0] =  dt * ty2;
      bu[j][i][3][0] =   0.0;
      bu[j][i][4][0] =   0.0;

      bu[j][i][0][1] =  dt * ty2
        * ( - ( u[k][j+1][i][1]*u[k][j+1][i][2] ) * tmp2 )
        - dt * ty1 * ( - c34 * tmp2 * u[k][j+1][i][1] );
      bu[j][i][1][1] =  dt * ty2 * ( u[k][j+1][i][2] * tmp1 )
        - dt * ty1 * ( c34 * tmp1 )
        - dt * ty1 * dy2;
      bu[j][i][2][1] =  dt * ty2 * ( u[k][j+1][i][1] * tmp1 );
      bu[j][i][3][1] = 0.0;
      bu[j][i][4][1] = 0.0;

      bu[j][i][0][2] =  dt * ty2
        * ( - ( u[k][j+1][i][2] * tmp1 ) * ( u[k][j+1][i][2] * tmp1 )
            + C2 * ( qs[k][j+1][i] * tmp1 ) )
        - dt * ty1 * ( - r43 * c34 * tmp2 * u[k][j+1][i][2] );
      bu[j][i][1][2] =  dt * ty2
        * ( - C2 * ( u[k][j+1][i][1] * tmp1 ) );
      bu[j][i][2][2] =  dt * ty2 * ( ( 2.0 - C2 )
          * ( u[k][j+1][i][2] * tmp1 ) )
        - dt * ty1 * ( r43 * c34 * tmp1 )
        - dt * ty1 * dy3;
      bu[j][i][3][2] =  dt * ty2
        * ( - C2 * ( u[k][j+1][i][3] * tmp1 ) );
      bu[j][i][4][2] =  dt * ty2 * C2;

      bu[j][i][0][3] =  dt * ty2
        * ( - ( u[k][j+1][i][2]*u[k][j+1][i][3] ) * tmp2 )
        - dt * ty1 * ( - c34 * tmp2 * u[k][j+1][i][3] );
      bu[j][i][1][3] = 0.0;
      bu[j][i][2][3] =  dt * ty2 * ( u[k][j+1][i][3] * tmp1 );
      bu[j][i][3][3] =  dt * ty2 * ( u[k][j+1][i][2] * tmp1 )
        - dt * ty1 * ( c34 * tmp1 )
        - dt * ty1 * dy4;
      bu[j][i][4][3] = 0.0;

      bu[j][i][0][4] =  dt * ty2
        * ( ( C2 * 2.0 * qs[k][j+1][i]
            - C1 * u[k][j+1][i][4] )
        * ( u[k][j+1][i][2] * tmp2 ) )
        - dt * ty1
        * ( - (     c34 - c1345 )*tmp3*(u[k][j+1][i][1]*u[k][j+1][i][1])
            - ( r43*c34 - c1345 )*tmp3*(u[k][j+1][i][2]*u[k][j+1][i][2])
            - (     c34 - c1345 )*tmp3*(u[k][j+1][i][3]*u[k][j+1][i][3])
            - c1345*tmp2*u[k][j+1][i][4] );
      bu[j][i][1][4] =  dt * ty2
        * ( - C2 * ( u[k][j+1][i][1]*u[k][j+1][i][2] ) * tmp2 )
        - dt * ty1
        * ( c34 - c1345 ) * tmp2 * u[k][j+1][i][1];
      bu[j][i][2][4] =  dt * ty2
        * ( C1 * ( u[k][j+1][i][4] * tmp1 )
            - C2 
            * ( qs[k][j+1][i] * tmp1
              + u[k][j+1][i][2]*u[k][j+1][i][2] * tmp2 ) )
        - dt * ty1
        * ( r43*c34 - c1345 ) * tmp2 * u[k][j+1][i][2];
      bu[j][i][3][4] =  dt * ty2
        * ( - C2 * ( u[k][j+1][i][2]*u[k][j+1][i][3] ) * tmp2 )
        - dt * ty1 * ( c34 - c1345 ) * tmp2 * u[k][j+1][i][3];
      bu[j][i][4][4] =  dt * ty2
        * ( C1 * ( u[k][j+1][i][2] * tmp1 ) )
        - dt * ty1 * c1345 * tmp1
        - dt * ty1 * dy5;

      //---------------------------------------------------------------------
      // form the third block sub-diagonal
      //---------------------------------------------------------------------
      tmp1 = rho_i[k+1][j][i];
      tmp2 = tmp1 * tmp1;
      tmp3 = tmp1 * tmp2;

      cu[j][i][0][0] = - dt * tz1 * dz1;
      cu[j][i][1][0] =   0.0;
      cu[j][i][2][0] =   0.0;
      cu[j][i][3][0] = dt * tz2;
      cu[j][i][4][0] =   0.0;

      cu[j][i][0][1] = dt * tz2
        * ( - ( u[k+1][j][i][1]*u[k+1][j][i][3] ) * tmp2 )
        - dt * tz1 * ( - c34 * tmp2 * u[k+1][j][i][1] );
      cu[j][i][1][1] = dt * tz2 * ( u[k+1][j][i][3] * tmp1 )
        - dt * tz1 * c34 * tmp1
        - dt * tz1 * dz2;
      cu[j][i][2][1] = 0.0;
      cu[j][i][3][1] = dt * tz2 * ( u[k+1][j][i][1] * tmp1 );
      cu[j][i][4][1] = 0.0;

      cu[j][i][0][2] = dt * tz2
        * ( - ( u[k+1][j][i][2]*u[k+1][j][i][3] ) * tmp2 )
        - dt * tz1 * ( - c34 * tmp2 * u[k+1][j][i][2] );
      cu[j][i][1][2] = 0.0;
      cu[j][i][2][2] = dt * tz2 * ( u[k+1][j][i][3] * tmp1 )
        - dt * tz1 * ( c34 * tmp1 )
        - dt * tz1 * dz3;
      cu[j][i][3][2] = dt * tz2 * ( u[k+1][j][i][2] * tmp1 );
      cu[j][i][4][2] = 0.0;

      cu[j][i][0][3] = dt * tz2
        * ( - ( u[k+1][j][i][3] * tmp1 ) * ( u[k+1][j][i][3] * tmp1 )
            + C2 * ( qs[k+1][j][i] * tmp1 ) )
        - dt * tz1 * ( - r43 * c34 * tmp2 * u[k+1][j][i][3] );
      cu[j][i][1][3] = dt * tz2
        * ( - C2 * ( u[k+1][j][i][1] * tmp1 ) );
      cu[j][i][2][3] = dt * tz2
        * ( - C2 * ( u[k+1][j][i][2] * tmp1 ) );
      cu[j][i][3][3] = dt * tz2 * ( 2.0 - C2 )
        * ( u[k+1][j][i][3] * tmp1 )
        - dt * tz1 * ( r43 * c34 * tmp1 )
        - dt * tz1 * dz4;
      cu[j][i][4][3] = dt * tz2 * C2;

      cu[j][i][0][4] = dt * tz2
        * ( ( C2 * 2.0 * qs[k+1][j][i]
            - C1 * u[k+1][j][i][4] )
                 * ( u[k+1][j][i][3] * tmp2 ) )
        - dt * tz1
        * ( - ( c34 - c1345 ) * tmp3 * (u[k+1][j][i][1]*u[k+1][j][i][1])
            - ( c34 - c1345 ) * tmp3 * (u[k+1][j][i][2]*u[k+1][j][i][2])
            - ( r43*c34 - c1345 )* tmp3 * (u[k+1][j][i][3]*u[k+1][j][i][3])
            - c1345 * tmp2 * u[k+1][j][i][4] );
      cu[j][i][1][4] = dt * tz2
        * ( - C2 * ( u[k+1][j][i][1]*u[k+1][j][i][3] ) * tmp2 )
        - dt * tz1 * ( c34 - c1345 ) * tmp2 * u[k+1][j][i][1];
      cu[j][i][2][4] = dt * tz2
        * ( - C2 * ( u[k+1][j][i][2]*u[k+1][j][i][3] ) * tmp2 )
        - dt * tz1 * ( c34 - c1345 ) * tmp2 * u[k+1][j][i][2];
      cu[j][i][3][4] = dt * tz2
        * ( C1 * ( u[k+1][j][i][4] * tmp1 )
            - C2
            * ( qs[k+1][j][i] * tmp1
              + u[k+1][j][i][3]*u[k+1][j][i][3] * tmp2 ) )
        - dt * tz1 * ( r43*c34 - c1345 ) * tmp2 * u[k+1][j][i][3];
      cu[j][i][4][4] = dt * tz2
        * ( C1 * ( u[k+1][j][i][3] * tmp1 ) )
        - dt * tz1 * c1345 * tmp1
        - dt * tz1 * dz5;
    }
  }


double scount = average_span*(ISIZ1/2*2+1)*5*5;
//double scount = (average_span-1)*(ISIZ1/2*2+1)*5*5;
double rcount = scount;
/*
ierr=MPI_Allgather( &au[lower_bound][0][0][0], scount, MPI_DOUBLE, &au[1][0][0][0], rcount, MPI_DOUBLE, MPI_COMM_WORLD);
ierr=MPI_Allgather( &bu[lower_bound][0][0][0], scount, MPI_DOUBLE, &bu[1][0][0][0], rcount, MPI_DOUBLE, MPI_COMM_WORLD);
ierr=MPI_Allgather( &cu[lower_bound][0][0][0], scount, MPI_DOUBLE, &cu[1][0][0][0], rcount, MPI_DOUBLE, MPI_COMM_WORLD);
ierr=MPI_Allgather( &du[lower_bound][0][0][0], scount, MPI_DOUBLE, &du[1][0][0][0], rcount, MPI_DOUBLE, MPI_COMM_WORLD);
*/
//ierr=MPI_Allgather( MPI_IN_PLACE, scount, MPI_DOUBLE, &au[1][0][0][0], rcount, MPI_DOUBLE, MPI_COMM_WORLD);
//ierr=MPI_Allgather( MPI_IN_PLACE, scount, MPI_DOUBLE, &bu[1][0][0][0], rcount, MPI_DOUBLE, MPI_COMM_WORLD);
//...ierr=MPI_Allgather( MPI_IN_PLACE, scount, MPI_DOUBLE, &cu[1][0][0][0], rcount, MPI_DOUBLE, MPI_COMM_WORLD);
//ierr=MPI_Allgather( MPI_IN_PLACE, scount, MPI_DOUBLE, &du[1][0][0][0], rcount, MPI_DOUBLE, MPI_COMM_WORLD);




kdeltas5 = (int *) malloc(pros_num*sizeof(int));
disps5 = (int *) malloc(pros_num*sizeof(int));
disps5[0] = 0;
rcounts5[0] = average_span*(ISIZ1/2*2+1)*5*5;


for(p5=1; p5<pros_num; p5++) {

rcounts5[p5] = average_span*(ISIZ1/2*2+1)*5*5;

//          if ((pros_num >=4)&& ((my_id+1)== pros_num)){
//          rcounts5[p5] =  last_pros_bound*(ISIZ1/2*2+1)*(5)*5;
//                }
disps5[p5] = disps5[p5-1] + rcounts5[p5-1];

}
ierr = MPI_Allgatherv(MPI_IN_PLACE,0,MPI_DATATYPE_NULL,&au[1][0][0][0],rcounts5,disps5,MPI_DOUBLE,MPI_COMM_WORLD);
ierr = MPI_Allgatherv(MPI_IN_PLACE,0,MPI_DATATYPE_NULL,&bu[1][0][0][0],rcounts5,disps5,MPI_DOUBLE,MPI_COMM_WORLD);
ierr = MPI_Allgatherv(MPI_IN_PLACE,0,MPI_DATATYPE_NULL,&cu[1][0][0][0],rcounts5,disps5,MPI_DOUBLE,MPI_COMM_WORLD);
ierr = MPI_Allgatherv(MPI_IN_PLACE,0,MPI_DATATYPE_NULL,&du[1][0][0][0],rcounts5,disps5,MPI_DOUBLE,MPI_COMM_WORLD);


/*
int tright;
int tleft;
int rankp1 = my_id+1;
int rankm1 = my_id-1;

    tright = 0;
    if(my_id == 0) {
        MPI_Send(&au[upper_bound-(average_span-2)][0][0][0],scount,MPI_DOUBLE,rankp1,tright,MPI_COMM_WORLD);
    } else {
        MPI_Recv(&au[lower_bound-average_span-1][0][0][0],rcount,MPI_DOUBLE,rankm1,tright,MPI_COMM_WORLD,&status);
         }

    tleft = 1;
    if(my_id == pros_num-1) {
        MPI_Send(&au[lower_bound][0][0][0],scount,MPI_DOUBLE,rankm1,tleft,MPI_COMM_WORLD);
    } else {
        MPI_Recv(&au[upper_bound+1][0][0][0],rcount,MPI_DOUBLE,rankp1,tleft,MPI_COMM_WORLD,&status);
     }

*/

}




